var searchData=
[
  ['gameloop',['GameLoop',['../engine_8c.html#a11ecd66918703cd65e3f4913d64abaae',1,'GameLoop(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c'],['../engine_8h.html#a11ecd66918703cd65e3f4913d64abaae',1,'GameLoop(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c']]],
  ['gerarnivel',['GerarNivel',['../engine_8c.html#ada28173b78ba14c861d2618ef1ed9d45',1,'GerarNivel(int horda):&#160;engine.c'],['../engine_8h.html#ada28173b78ba14c861d2618ef1ed9d45',1,'GerarNivel(int horda):&#160;engine.c']]],
  ['gerarvalor',['GerarValor',['../engine_8c.html#a3e2d58153cc2c5d510bdfc229bdae3fd',1,'GerarValor(int a, int b):&#160;engine.c'],['../engine_8h.html#a3e2d58153cc2c5d510bdfc229bdae3fd',1,'GerarValor(int a, int b):&#160;engine.c']]]
];
