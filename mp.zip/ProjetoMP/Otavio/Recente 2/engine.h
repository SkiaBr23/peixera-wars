/*
PROJETO
Nome: MAXIMILLIAN FAN XAVIER, OT�VIO ALVES DIAS, RAFAEL DIAS DA COSTA, T�LIO ABNER DE LIMA
Matr�cula: 12/0153271, 12/0131480, 12/0133253, 12/0137194
Curso: Engenharia de Computa��o
Disciplina: M�todos de Programa��o
Turma: A
Prof: Jan Mendon�a
*/

/*	Arquivo Header	*/
#include <stdio.h>

/*	---------------DEFINI��O DE FUN��ES---------------	*/

/*FUN��ES DA ENGINE*/
void CriaEstruturas();
void InicializaEstruturas();
int VerificaInterface();
CabecaGeral* StartGame();
void SaveGame();
void LoadGame();
int MenuEvolucaoEdificio();
int MenuEscolhaUnidade();
void Run();