var searchData=
[
  ['unidade',['unidade',['../structunidade.html',1,'unidade'],['../estruturas_8h.html#a0ebbe6457da14a6f9da4407e7c3f4b67',1,'Unidade():&#160;estruturas.h']]],
  ['unidadevazia',['UnidadeVazia',['../estruturas_8h.html#afbe5cc91d835ff47950e48790fe1949c',1,'UnidadeVazia(Unidade *lis):&#160;funcoes.c'],['../funcoes_8c.html#afbe5cc91d835ff47950e48790fe1949c',1,'UnidadeVazia(Unidade *lis):&#160;funcoes.c']]]
];
