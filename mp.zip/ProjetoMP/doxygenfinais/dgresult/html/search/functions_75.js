var searchData=
[
  ['unidadevazia',['UnidadeVazia',['../estruturas_8h.html#afbe5cc91d835ff47950e48790fe1949c',1,'UnidadeVazia(Unidade *lis):&#160;funcoes.c'],['../funcoes_8c.html#afbe5cc91d835ff47950e48790fe1949c',1,'UnidadeVazia(Unidade *lis):&#160;funcoes.c']]]
];
