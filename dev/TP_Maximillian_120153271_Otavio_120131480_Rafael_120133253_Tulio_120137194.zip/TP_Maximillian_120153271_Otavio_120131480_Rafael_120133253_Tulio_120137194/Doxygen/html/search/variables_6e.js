var searchData=
[
  ['nivel',['nivel',['../structunidade.html#afafcd32854d6f6b1c4cd3cca8f1315a7',1,'unidade::nivel()'],['../structedificio.html#afafcd32854d6f6b1c4cd3cca8f1315a7',1,'edificio::nivel()'],['../structcomercio.html#afafcd32854d6f6b1c4cd3cca8f1315a7',1,'comercio::nivel()']]]
];
