var searchData=
[
  ['edificiovazia',['EdificioVazia',['../estruturas_8h.html#a964aab53c47a7e3ae3fa50ba5ffdbd3c',1,'EdificioVazia(Edificio *lis):&#160;funcoes.c'],['../funcoes_8c.html#a964aab53c47a7e3ae3fa50ba5ffdbd3c',1,'EdificioVazia(Edificio *lis):&#160;funcoes.c']]]
];
