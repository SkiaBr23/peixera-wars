var searchData=
[
  ['verificaestrutura',['VerificaEstrutura',['../estruturas_8h.html#ac41c495059d51b13c6d5699ab04d1667',1,'VerificaEstrutura(Unidade *lista):&#160;funcoes.c'],['../funcoes_8c.html#ac41c495059d51b13c6d5699ab04d1667',1,'VerificaEstrutura(Unidade *lista):&#160;funcoes.c']]],
  ['verificainterface',['VerificaInterface',['../engine_8c.html#a29fbb966bbea575a0e841e6fd967dfdf',1,'VerificaInterface(CabecaGeral *Interface):&#160;engine.c'],['../engine_8h.html#a8c16ce09f0f38cf6cb98341a88bf1738',1,'VerificaInterface(CabecaGeral *Interface):&#160;engine.c']]],
  ['verificarcabecageral',['VerificarCabecaGeral',['../estruturas_8h.html#abfb14d52dadba35ae1bef5bef4af6dbb',1,'VerificarCabecaGeral(CabecaGeral *CG):&#160;funcoes.c'],['../funcoes_8c.html#abfb14d52dadba35ae1bef5bef4af6dbb',1,'VerificarCabecaGeral(CabecaGeral *CG):&#160;funcoes.c']]],
  ['verificarcastelo',['VerificarCastelo',['../estruturas_8h.html#af552ec753dbfd8faa5ba633bc8f37fab',1,'VerificarCastelo(Castelo *C):&#160;funcoes.c'],['../funcoes_8c.html#af552ec753dbfd8faa5ba633bc8f37fab',1,'VerificarCastelo(Castelo *C):&#160;funcoes.c']]]
];
