var searchData=
[
  ['quartel',['quartel',['../structcastelo.html#a0d096fd01efb245bb3fed56f87da404c',1,'castelo']]]
];
