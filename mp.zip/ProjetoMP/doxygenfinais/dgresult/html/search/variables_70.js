var searchData=
[
  ['player',['player',['../structcabecapfilas.html#a62974e000e6746f21eb4f0e6e12238f6',1,'cabecapfilas']]],
  ['prox',['prox',['../structunidade.html#a7f4ce5c1013e03c4e99c3772904235e5',1,'unidade']]]
];
