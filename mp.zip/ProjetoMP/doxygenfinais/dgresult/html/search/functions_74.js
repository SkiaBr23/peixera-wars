var searchData=
[
  ['tela_5ffinal',['tela_final',['../grafico_8c.html#a71610923bdf8b770790c386b6cd18b63',1,'tela_final():&#160;grafico.c'],['../grafico_8h.html#a71610923bdf8b770790c386b6cd18b63',1,'tela_final():&#160;grafico.c']]],
  ['tela_5finicial',['tela_inicial',['../grafico_8c.html#a2a194251baa5812baac5606d21cd97e5',1,'tela_inicial():&#160;grafico.c'],['../grafico_8h.html#a2a194251baa5812baac5606d21cd97e5',1,'tela_inicial():&#160;grafico.c']]],
  ['telagameover',['TelaGameOver',['../grafico_8c.html#a783f9e9e4570e2857eaf5a9df635e5d2',1,'TelaGameOver():&#160;grafico.c'],['../grafico_8h.html#af494143d818c67bcbbda3ce40151d1f1',1,'TelaGameOver():&#160;grafico.c']]],
  ['temquatro',['TemQuatro',['../engine_8c.html#ae5f10c129fd58770cfb90b5a64ac3e4c',1,'TemQuatro(Unidade *lista):&#160;engine.c'],['../engine_8h.html#a06cb6d41fd5d0e46c2c625fca70c7d86',1,'TemQuatro(Unidade *lista):&#160;engine.c']]]
];
