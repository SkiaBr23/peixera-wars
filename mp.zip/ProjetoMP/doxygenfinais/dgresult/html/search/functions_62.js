var searchData=
[
  ['batalha',['Batalha',['../engine_8c.html#a2d11fcea9230ba8118a1ead7cc6679a7',1,'Batalha(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c'],['../engine_8h.html#a2d11fcea9230ba8118a1ead7cc6679a7',1,'Batalha(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c']]],
  ['batalha2',['Batalha2',['../engine_8c.html#ab63bec7fdc9c6e5eff4ad4b6cce7202b',1,'Batalha2(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c'],['../engine_8h.html#ab63bec7fdc9c6e5eff4ad4b6cce7202b',1,'Batalha2(CabecaGeral *Interface, WINDOW *winfield):&#160;engine.c']]],
  ['buscaalvo',['buscaAlvo',['../engine_8c.html#ad5fa5edd114269f709f94136f30a5bd0',1,'buscaAlvo(Unidade *vitima):&#160;engine.c'],['../engine_8h.html#aa9b973c127cb8ce1ff4191ee2b9a8ea4',1,'buscaAlvo(Unidade *vitima):&#160;engine.c']]]
];
