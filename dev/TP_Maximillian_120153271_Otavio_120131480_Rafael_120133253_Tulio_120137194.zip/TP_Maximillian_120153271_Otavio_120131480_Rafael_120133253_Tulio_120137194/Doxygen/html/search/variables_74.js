var searchData=
[
  ['taxaouro',['taxaouro',['../structcomercio.html#ad0eebe3dcaa5b98c97b0c563b0554860',1,'comercio']]]
];
