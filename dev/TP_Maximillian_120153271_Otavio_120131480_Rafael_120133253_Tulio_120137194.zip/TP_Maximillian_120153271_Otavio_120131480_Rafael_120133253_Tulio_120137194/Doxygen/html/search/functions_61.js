var searchData=
[
  ['atacar',['Atacar',['../engine_8c.html#a921bd1c1c6c9b7c62e48486f7b7cacb9',1,'Atacar(Unidade *atacante, Unidade *vitima):&#160;engine.c'],['../engine_8h.html#a547174285bc62d100a1b0f0d2e2f26da',1,'Atacar(Unidade *atacante, Unidade *vitima):&#160;engine.c']]],
  ['ataqueinimigo',['AtaqueInimigo',['../engine_8c.html#a74c32cc1cdc57ede7f2e98095e4f95ee',1,'AtaqueInimigo(int *hit, Unidade *atacante, Unidade *vitima):&#160;engine.c'],['../engine_8h.html#a9cca18cda3d905f60b5baf93b6548ee8',1,'AtaqueInimigo(int *hit, Unidade *atacante, Unidade *vitima):&#160;engine.c']]],
  ['atualizarcasteloouro',['AtualizarCasteloOuro',['../estruturas_8h.html#a43cede037d244cd94f7bfd6ab54fba28',1,'AtualizarCasteloOuro(Castelo *C, int ouro):&#160;funcoes.c'],['../funcoes_8c.html#ae558988a1b91d7b0cb6b9fbb51e548c8',1,'AtualizarCasteloOuro(Castelo *C, int ouro):&#160;funcoes.c']]]
];
