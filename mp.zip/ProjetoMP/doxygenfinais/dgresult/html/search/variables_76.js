var searchData=
[
  ['vida',['vida',['../structunidade.html#a5ad38abe22f6739f387e4653850ed5ee',1,'unidade']]]
];
