var searchData=
[
  ['limpalista',['LimpaLista',['../estruturas_8h.html#ac0fa0b234ba7cb5223d6f02417da52cf',1,'LimpaLista(Unidade *lis):&#160;funcoes.c'],['../funcoes_8c.html#a6c85feb248431f68f1d4f6da8f8c4b6d',1,'LimpaLista(Unidade *lis):&#160;funcoes.c']]],
  ['loadgame',['LoadGame',['../engine_8c.html#ab0e5cf3e0686edf88442f5977c0f8875',1,'LoadGame():&#160;engine.c'],['../engine_8h.html#ab0e5cf3e0686edf88442f5977c0f8875',1,'LoadGame():&#160;engine.c']]]
];
