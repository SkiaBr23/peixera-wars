var searchData=
[
  ['savegame',['SaveGame',['../engine_8c.html#a6f195ba03705b5d4dfb5005f14851ce4',1,'SaveGame(CabecaGeral *Interface, int horda):&#160;engine.c'],['../engine_8h.html#a0311c8c4da7f77e4e454b31152575d87',1,'SaveGame(CabecaGeral *Interface, int horda):&#160;engine.c']]],
  ['seta',['seta',['../grafico_8c.html#ac721cf711a36f6455044b3c1d1c5b42a',1,'seta(WINDOW *win, int tipo, int y, int x):&#160;grafico.c'],['../grafico_8h.html#ac721cf711a36f6455044b3c1d1c5b42a',1,'seta(WINDOW *win, int tipo, int y, int x):&#160;grafico.c']]],
  ['seta_5fbatalha',['seta_batalha',['../grafico_8c.html#abbe40fd399048d4a423cb4b8fe0b5170',1,'seta_batalha(WINDOW *winfield, int j, int i):&#160;grafico.c'],['../grafico_8h.html#abbe40fd399048d4a423cb4b8fe0b5170',1,'seta_batalha(WINDOW *winfield, int j, int i):&#160;grafico.c']]],
  ['startgame',['StartGame',['../engine_8c.html#a705e7f5b63a151af49498001a47db4a2',1,'StartGame(CabecaGeral *Cabeca, int horda):&#160;engine.c'],['../engine_8h.html#a67c2f1a29a5e9f304ebad03b4818ef43',1,'StartGame(CabecaGeral *Cabeca, int horda):&#160;engine.c']]]
];
