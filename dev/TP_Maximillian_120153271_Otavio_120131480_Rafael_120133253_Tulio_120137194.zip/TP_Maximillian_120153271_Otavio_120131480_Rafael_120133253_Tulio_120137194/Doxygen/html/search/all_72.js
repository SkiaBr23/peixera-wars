var searchData=
[
  ['removerunidade',['RemoverUnidade',['../estruturas_8h.html#a6fcd097166fac054f380ebe70dbb92bb',1,'RemoverUnidade(Unidade *lis, Unidade *retira):&#160;funcoes.c'],['../funcoes_8c.html#a7256170614a5d2342da76779cb6501ef',1,'RemoverUnidade(Unidade *lis, Unidade *retira):&#160;funcoes.c']]],
  ['removerunidadefinal',['RemoverUnidadeFinal',['../estruturas_8h.html#a407a2210492b16725135a1c8effed6e0',1,'RemoverUnidadeFinal(Unidade *lis):&#160;funcoes.c'],['../funcoes_8c.html#a4aa74175e5f5b5dc0c37bc23560fe110',1,'RemoverUnidadeFinal(Unidade *lis):&#160;funcoes.c']]],
  ['run',['Run',['../engine_8c.html#a144251760f16b8bdc21587e6a3d86402',1,'Run(CabecaGeral *Interface, int new, int wave):&#160;engine.c'],['../engine_8h.html#a144251760f16b8bdc21587e6a3d86402',1,'Run(CabecaGeral *Interface, int new, int wave):&#160;engine.c']]]
];
