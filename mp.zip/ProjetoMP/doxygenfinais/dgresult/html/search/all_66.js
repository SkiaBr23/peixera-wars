var searchData=
[
  ['finaliza_5fncurses',['finaliza_ncurses',['../grafico_8c.html#a2f1d963decc31d951961b439eae2fd82',1,'finaliza_ncurses():&#160;grafico.c'],['../grafico_8h.html#a2f1d963decc31d951961b439eae2fd82',1,'finaliza_ncurses():&#160;grafico.c']]],
  ['funcoes_2ec',['funcoes.c',['../funcoes_8c.html',1,'']]]
];
