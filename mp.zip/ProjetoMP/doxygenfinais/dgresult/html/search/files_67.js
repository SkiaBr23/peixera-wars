var searchData=
[
  ['grafico_2ec',['grafico.c',['../grafico_8c.html',1,'']]],
  ['grafico_2eh',['grafico.h',['../grafico_8h.html',1,'']]]
];
