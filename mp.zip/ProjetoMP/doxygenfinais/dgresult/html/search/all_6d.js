var searchData=
[
  ['main',['main',['../peixera_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'peixera.c']]],
  ['mensagem',['mensagem',['../grafico_8c.html#acd1cee52d27e57acd84d6d25dfd96bfb',1,'mensagem(int y, int x, char frase[]):&#160;grafico.c'],['../grafico_8h.html#acd1cee52d27e57acd84d6d25dfd96bfb',1,'mensagem(int y, int x, char frase[]):&#160;grafico.c']]],
  ['mensagem_5fentrada',['mensagem_entrada',['../grafico_8c.html#a6dee66272c6ef14c938f4b5263110211',1,'mensagem_entrada(int y, int x, char frase[]):&#160;grafico.c'],['../grafico_8h.html#a91065c5c1d0ae136bc276ce0f5220f4c',1,'mensagem_entrada(int y, int x, char frase[]):&#160;grafico.c']]],
  ['menu',['menu',['../grafico_8c.html#a891d476534652b9bf3b3435839a19192',1,'menu(WINDOW *menuwin):&#160;grafico.c'],['../grafico_8h.html#ae83fcdbeb2b6757fc741ae953b633ee1',1,'menu():&#160;grafico.h']]],
  ['menu_5fedificio',['menu_edificio',['../grafico_8c.html#ae41ff83d1436eae547973220b8b01f4d',1,'menu_edificio():&#160;grafico.c'],['../grafico_8h.html#ae41ff83d1436eae547973220b8b01f4d',1,'menu_edificio():&#160;grafico.c']]],
  ['menu_5funidade',['menu_unidade',['../grafico_8c.html#a26358a3d267b436a3be769bbfe61ef5d',1,'menu_unidade(Castelo *castelo):&#160;grafico.c'],['../grafico_8h.html#a9a92c2fa8f6fe9d707bf6dbcae444db2',1,'menu_unidade():&#160;grafico.h']]],
  ['menuescolhaunidade',['MenuEscolhaUnidade',['../engine_8c.html#a74274a328cbe9b809b079cd7a63e526f',1,'MenuEscolhaUnidade(CabecaGeral *Interface):&#160;engine.c'],['../engine_8h.html#a7995935cdb1451e1175833c36695708a',1,'MenuEscolhaUnidade(CabecaGeral *Interface):&#160;engine.c']]],
  ['menuevolucaoedificio',['MenuEvolucaoEdificio',['../engine_8c.html#a3ba2629d0ea83a831e30b8bbc675ffc6',1,'MenuEvolucaoEdificio(CabecaGeral *Interface):&#160;engine.c'],['../engine_8h.html#a3ba2629d0ea83a831e30b8bbc675ffc6',1,'MenuEvolucaoEdificio(CabecaGeral *Interface):&#160;engine.c']]]
];
